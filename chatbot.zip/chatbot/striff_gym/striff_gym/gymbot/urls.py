# gymbot/urls.py
from django.urls import path
from gymbot import views

urlpatterns = [
    path('chat/', views.chat, name='chat'),
]
