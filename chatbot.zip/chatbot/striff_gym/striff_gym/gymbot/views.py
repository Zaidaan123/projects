# Create your views here.
# gymbot/views.py
from django.shortcuts import render

def chat(request):
    return render(request, 'gymbot/chat.html')
