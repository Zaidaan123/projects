from django.apps import AppConfig


class GymbotConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gymbot'
