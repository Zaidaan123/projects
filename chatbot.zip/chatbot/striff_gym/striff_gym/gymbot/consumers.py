# gymbot/consumers.py

import json
from channels.generic.websocket import WebsocketConsumer

class ChatConsumer(WebsocketConsumer):
    def connect(self):
        self.accept()
        # Send an initial welcome message from the bot when the user connects
        self.send(text_data=json.dumps({
            'message': 'Hello! Welcome to Striff Gym. How can I assist you today?'
        }))

    def disconnect(self, close_code):
        # Handle any disconnection logic if needed
        print(f"WebSocket disconnected: {close_code}")

    def receive(self, text_data):
        # Parse the message from the client
        data = json.loads(text_data)
        user_message = data.get('message', '')

        # Define bot responses based on user input (simple demo logic)
        if 'membership' in user_message.lower():
            bot_message = 'Our membership plans start at $30 per month. Would you like more details?'
        elif 'schedule' in user_message.lower():
            bot_message = 'You can view the class schedule on our website or let me know what type of class you’re interested in.'
        elif 'trainer' in user_message.lower():
            bot_message = 'We have personal trainers available. Would you like to book a session?'
        else:
            bot_message = 'I’m not sure how to help with that. Could you try rephrasing your question?'

        # Send the response back to the client
        self.send(text_data=json.dumps({
            'message': bot_message
        }))
